#pragma once

int calc(const char* text);

